//
//  SJLineChartMianView.m
//  SJChartViewDemo
//
//  Created by Jaesun on 16/9/8.
//  Copyright © 2016年 S.J. All rights reserved.
//

#import "SJLineChartMianView.h"

// Tag 基本值
#define BASE_TAG_COVERVIEW 100
#define BASE_TAG_CIRCLEVIEW 200
#define BASE_TAG_POPBTN 300


@implementation SJLineChartMianView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self s_setupViews];
    }
    return  self;
}
- (void)s_setupViews {

    // 画折线图
    {
        
        self.valueArray = @[@40,@50,@70,@50,@60];
        pointArray = [NSMutableArray array];
        
        UIBezierPath *pAxisPath = [[UIBezierPath alloc] init];
        
        for (int i = 0; i < self.valueArray.count; i ++) {
            
            CGFloat perMark_W = xAxis_L / (self.xMarkCount - 1);
            CGFloat point_X = perMark_W * i + start_X;
            
            CGFloat value = [self.valueArray[i] floatValue];
            CGFloat percent = value / self.maxValue;
            CGFloat point_Y = yAxis_L * (1 - percent) + start_Y;
            
            CGPoint point = CGPointMake(point_X, point_Y);
            
            [pointArray addObject:[NSValue valueWithCGPoint:point]];
            
            if (i == 0) {
                [pAxisPath moveToPoint:point];
            }
            else {
                [pAxisPath addLineToPoint:point];
            }
        }
        
        CAShapeLayer *pAxisLayer = [CAShapeLayer layer];
        pAxisLayer.lineWidth = 1;
        pAxisLayer.strokeColor = [UIColor greenColor].CGColor;
        pAxisLayer.fillColor = [UIColor clearColor].CGColor;
        pAxisLayer.path = pAxisPath.CGPath;
        [self.layer addSublayer:pAxisLayer];
    }
    
    // 渐变阴影
    {
        UIBezierPath *gradientPath = [[UIBezierPath alloc] init];
        
        [gradientPath moveToPoint:CGPointMake(start_X, yAxis_L)];
        
        for (int i = 0; i < pointArray.count; i ++) {
            
            [gradientPath addLineToPoint:[pointArray[i] CGPointValue]];
        }
        
        CGPoint endPoint = [[pointArray lastObject] CGPointValue];
        endPoint = CGPointMake(endPoint.x, yAxis_L);
        [gradientPath addLineToPoint:endPoint];
        
        CAGradientLayer *gradientLayer = [CAGradientLayer layer];
        gradientLayer.frame = CGRectMake(0, 0, viewWidth, yAxis_L);
        gradientLayer.colors = @[(__bridge id)[UIColor colorWithRed:50/255.0 green:255/255.0 blue:50/255.0 alpha:0.8].CGColor,(__bridge id)[UIColor colorWithRed:225/255.0 green:255/255.0 blue:225/255.0 alpha:0.2].CGColor];
        gradientLayer.accessibilityPath = gradientPath;
        gradientLayer.locations=@[@0.0,@1.0];
        gradientLayer.startPoint = CGPointMake(0.0,0.0);
        gradientLayer.endPoint = CGPointMake(0.0,1);
        
        CAShapeLayer *arc = [CAShapeLayer layer];
        arc.path = gradientPath.CGPath;
        gradientLayer.mask = arc;
        
        [self.layer addSublayer:gradientLayer];
        
    }
    // 圆环
    {
        for (int i = 0; i < pointArray.count; i ++) {
            
            SJCircleView *circleView = [[SJCircleView alloc] initWithCenter:[pointArray[i] CGPointValue] radius:4];
            circleView.tag = i + BASE_TAG_CIRCLEVIEW;
            circleView.borderColor = [UIColor greenColor];
            circleView.borderWidth = 1.0;
            [self addSubview:circleView];
        }
    }
    // 蒙版视图
    {
        for (int i = 0; i < pointArray.count; i ++) {
            
            UIView *coverView = [[UIView alloc] init];
            coverView.tag = BASE_TAG_COVERVIEW + i;
            
            UITapGestureRecognizer *gesutre = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gesutreAction:)];
            [coverView addGestureRecognizer:gesutre];
            
            if (i == 0) {
                
                coverView.frame = CGRectMake(start_X, start_Y, PerItemWidth  / 2, yAxis_L);
                coverView.backgroundColor = [UIColor colorWithRed:arc4random() % 256 / 255.0 green:arc4random() % 256 / 255.0 blue:arc4random() % 256 / 255.0 alpha:0.6];
                [self addSubview:coverView];
            }
            else if (i == pointArray.count - 1) {
                CGPoint point = [pointArray[i] CGPointValue];
                coverView.frame = CGRectMake(point.x - PerItemWidth / 2, start_Y, PerItemWidth  / 2, yAxis_L);
                coverView.backgroundColor = [UIColor colorWithRed:arc4random() % 256 / 255.0 green:arc4random() % 256 / 255.0 blue:arc4random() % 256 / 255.0 alpha:0.6];
                [self addSubview:coverView];
            }
            else {
                CGPoint point = [pointArray[i] CGPointValue];
                coverView.frame = CGRectMake(point.x - PerItemWidth / 2, start_Y, PerItemWidth, yAxis_L);
                coverView.backgroundColor = [UIColor colorWithRed:arc4random() % 256 / 255.0 green:arc4random() % 256 / 255.0 blue:arc4random() % 256 / 255.0 alpha:0.6];
                [self addSubview:coverView];
            }
        }
    }
}

- (void)gesutreAction:(UITapGestureRecognizer *)sender {
    
    NSInteger index = sender.view.tag - BASE_TAG_COVERVIEW;
    
    if (lastSeletedIndex != -1) {
        
        SJCircleView *lastCircleView = (SJCircleView *)[self viewWithTag:lastSeletedIndex + BASE_TAG_CIRCLEVIEW];
        lastCircleView.borderWidth = 1;
        
        UIButton *lastPopBtn = (UIButton *)[self viewWithTag:lastSeletedIndex + BASE_TAG_POPBTN];
        [lastPopBtn removeFromSuperview];
    }
    
    SJCircleView *circleView = (SJCircleView *)[self viewWithTag:index + BASE_TAG_CIRCLEVIEW];
    circleView.borderWidth = 2;
    
    CGPoint point = [pointArray[index] CGPointValue];
    
    UIButton *popBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    popBtn.tag = index + BASE_TAG_POPBTN;
    popBtn.frame = CGRectMake(point.x - 13, point.y - 25, 26, 16);
    [popBtn setBackgroundImage:[UIImage imageNamed:@"btg_pop_bg.png"] forState:UIControlStateNormal];
    [popBtn setTitleEdgeInsets:UIEdgeInsetsMake(-3, 0, 0, 0)];
    popBtn.titleLabel.font = [UIFont systemFontOfSize:11];
    [popBtn setTitle:[NSString stringWithFormat:@"%@",self.valueArray[index]] forState:(UIControlStateNormal)];
    popBtn.enabled = NO;
    [self addSubview:popBtn];
    
    lastSeletedIndex = index;
}

@end
